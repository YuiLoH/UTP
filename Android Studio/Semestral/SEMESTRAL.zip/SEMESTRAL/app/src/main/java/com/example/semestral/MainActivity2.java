package com.example.semestral;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;

import java.io.File;
import java.util.ArrayList;

public class MainActivity2 extends AppCompatActivity {

    private ListView listView;
    private ImageView imageView1;
    private String[] archivos;
    private ArrayAdapter<String> adaptador;
    private String ruta;
    private Button btn;
    private int selectFoto;

    private RecyclerView recyclerView;
    private CheckBox chk_select_all;
    private Button btn_delete_all;

    private ArrayList<Model> item_list = new ArrayList<>();
    private ModelAdapter mAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        File dir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        archivos = dir.list();
        adaptador = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,archivos);
        listView = findViewById(R.id.listView);
        listView.setAdapter(adaptador);

        imageView1 = findViewById(R.id.imageView1);
        btn = findViewById(R.id.btn3);

        if (archivos.length != 0) {
            imageView1.setImageBitmap(MainActivity2.girarFoto(BitmapFactory.decodeFile(getExternalFilesDir(Environment.DIRECTORY_PICTURES) + "/" + archivos[0])));
        }

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                imageView1.setImageBitmap(MainActivity2.girarFoto(BitmapFactory.decodeFile(getExternalFilesDir(Environment.DIRECTORY_PICTURES) + "/" + archivos[i])));
                btn.setVisibility(View.VISIBLE);
                selectFoto = i;
            }
        });

    }

    public void eliminarFoto(View view) {
        try {

            File dir = new File(getExternalFilesDir(Environment.DIRECTORY_PICTURES)+"/"+archivos[selectFoto]);
            if (dir.exists()){
                dir.delete();
                Toast.makeText(this, "Foto eliminada", Toast.LENGTH_LONG).show();
                reloadList();

                if (archivos.length != 0)
                    imageView1.setImageBitmap(MainActivity2.girarFoto(BitmapFactory.decodeFile(getExternalFilesDir(Environment.DIRECTORY_PICTURES) + "/" + archivos[0])));
                else {
                    Intent intent = new Intent(this, MainActivity.class);
                    startActivityForResult(intent,1);
                }

                btn.setVisibility(View.INVISIBLE);
            } else {
                Toast.makeText(this,"No es una dirección",Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e){
            Toast.makeText(this,"No se eliminó la foto "+ e.getMessage(),Toast.LENGTH_LONG).show();
        }
    }

    private void reloadList(){
        File dir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        archivos = dir.list();
        adaptador = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,archivos);
        listView = findViewById(R.id.listView);
        listView.setAdapter(adaptador);
    }

    private static Bitmap girarFoto(Bitmap fotoFea) {
        Matrix matrix = new Matrix();
        matrix.postRotate(90);
        return Bitmap.createBitmap(fotoFea, 0, 0, fotoFea.getWidth(), fotoFea.getHeight(), matrix, true);
    }
}