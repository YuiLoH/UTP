package com.example.semestral;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Environment;
import android.util.Base64;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class MainActivity2 extends AppCompatActivity {

    private ListView listView;
    private ImageView imageView1;
    private String[] archivos;
    private ArrayAdapter<String> adaptador;
    private String ruta;
    private LinearLayout rlayout1;
    private int selectFoto;
    Bitmap decoded;
    RequestQueue requestQueue;

    ImageButton btn_cargarImagen;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        btn_cargarImagen = findViewById(R.id.btn_carga);

        File dir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        archivos = dir.list();
        adaptador = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,archivos);
        listView = findViewById(R.id.listView);
        listView.setAdapter(adaptador);

        imageView1 = findViewById(R.id.imageView1);
        rlayout1 = (LinearLayout) findViewById(R.id.btn_eliminar);

        requestQueue = Volley.newRequestQueue(this);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Bitmap bitmap = BitmapFactory.decodeFile(getExternalFilesDir(Environment.DIRECTORY_PICTURES) + "/" + archivos[i]);
                setToImageView(getResizedBitmap(bitmap, 1024));
                rlayout1.setVisibility(View.VISIBLE);
                selectFoto = i;
            }
        });

        btn_cargarImagen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                cargarImagen();
            }
        });

    }

    public void eliminarFoto(View view) {
        try {

            File dir = new File(getExternalFilesDir(Environment.DIRECTORY_PICTURES)+"/"+archivos[selectFoto]);
            if (dir.exists()){
                dir.delete();
                Toast.makeText(this, "Foto eliminada", Toast.LENGTH_LONG).show();
                imageView1.setImageResource(android.R.mipmap.sym_def_app_icon);
                reloadList();
                rlayout1.setVisibility(View.INVISIBLE);
            } else {
                Toast.makeText(this,"No es una dirección",Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e){
            Toast.makeText(this,"No se eliminó la foto "+ e.getMessage(),Toast.LENGTH_LONG).show();
        }
    }

    private void reloadList(){
        File dir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        archivos = dir.list();
        adaptador = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,archivos);
        listView = findViewById(R.id.listView);
        listView.setAdapter(adaptador);
    }

    private void setToImageView(Bitmap bitmap) {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, bytes);
        decoded = BitmapFactory.decodeStream(new ByteArrayInputStream(bytes.toByteArray()));
        imageView1.setImageBitmap(decoded);
    }

    private Bitmap getResizedBitmap(Bitmap bitmap, int maxsize) {
        int width = bitmap.getWidth();
        int heigth = bitmap.getHeight();

        if(width <= maxsize && heigth <= maxsize){
            return bitmap;
        }

        float bitmapRatio = (float) width/(float)heigth;
        if(bitmapRatio>1){
            width = maxsize;
            heigth = (int) (width/bitmapRatio);
        }else{
            heigth = maxsize;
            width = (int) (heigth * bitmapRatio);
        }

        return Bitmap.createScaledBitmap(bitmap, width, heigth, true);
    }

    private void cargarImagen(){
        String URL = "https://semestralutp.webcindario.com/upload.php";
        final ProgressDialog loading = ProgressDialog.show(this,"Subiendo...","Espere por favor...",false,false);
        StringRequest stringRequest = new StringRequest(
                Request.Method.POST,
                URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        //Descartar el diálogo de progreso
                        loading.dismiss();
                        //Mostrando el mensaje de la respuesta
                        Toast.makeText(MainActivity2.this, response , Toast.LENGTH_LONG).show();
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError volleyError) {
                        loading.dismiss();
                        Toast.makeText(MainActivity2.this, volleyError.getMessage().toString(), Toast.LENGTH_LONG).show();
                    }
                }
        ){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();

                params.put("path", getStringimage(decoded));
                return super.getParams();
            }
        };

        requestQueue.add(stringRequest);
    }

    private String getStringimage(Bitmap bitmap) {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos);
        byte[] imageBytes = baos.toByteArray();

        return Base64.encodeToString(imageBytes, Base64.DEFAULT);
    }

}